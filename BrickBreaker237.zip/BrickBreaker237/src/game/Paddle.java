package game;

public class Paddle {

}
