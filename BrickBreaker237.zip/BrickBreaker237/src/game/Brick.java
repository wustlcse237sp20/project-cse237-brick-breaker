package game;

public interface Brick {
	//	destroys brick when health is reduced
	public void destroyBrick();
	//	apply damage when brick is hit
	public void damageBrick();
	
}
