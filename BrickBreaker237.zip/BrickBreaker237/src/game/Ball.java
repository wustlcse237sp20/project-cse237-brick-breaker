package game;

public class Ball {

}
