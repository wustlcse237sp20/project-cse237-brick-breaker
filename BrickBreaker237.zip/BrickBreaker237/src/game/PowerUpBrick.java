package game;

public class PowerUpBrick implements Brick {

	@Override
	public void destroyBrick() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void damageBrick() {
		// TODO Auto-generated method stub
		
	}

}
