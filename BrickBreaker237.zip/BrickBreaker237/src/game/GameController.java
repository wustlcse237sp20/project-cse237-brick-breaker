package game;

public class GameController {
//init gameboard
//start and manage game 
}
