package game;

public class GameBoard {
// init ball
// init paddle
// init breakable bricks
// init powerups
}
